import { Weapon } from "../weapons/Weapon.js";
import { WEAPONS } from "../weapons/weaponsData.js";


export class Player {

    constructor(
        scene,
        x,
        y,
        walls
    ) {

        this.scene = scene;

        this.speed = 300;

        this.health = 100;

        this.dead = false;

        this.currentWeapon =
            "pistol";

        this.isShooting =
            false;


        // =========================
        // ARMA
        // =========================

        this.weapon =
            new Weapon(
                scene,
                WEAPONS.PISTOLA
            );


        // =========================
        // INPUT
        // =========================

        this.keys =
            scene.input.keyboard.addKeys({
                up: "W",
                down: "S",
                left: "A",
                right: "D"
            });


        // =========================
        // SPRITES
        // =========================

        this.createFrames();

        this.createAnimations();


        // =========================
        // CORPO FÍSICO
        // =========================

        this.body =
            scene.physics.add.sprite(
                x,
                y,
                "playerSheet",
                "idle"
            );


        this.body.setVisible(
            false
        );


        // =========================
        // HITBOX
        // =========================

        this.body.body.setSize(
            34,
            48,
            true
        );


        this.body.setCollideWorldBounds(
            true
        );


        scene.physics.add.collider(
            this.body,
            walls
        );

        // =========================
        // SPRITE VISUAL
        // =========================

        this.sprite =
            scene.add.sprite(
                x,
                y,
                "playerSheet",
                "pistolIdle"
            );


        this.sprite.setScale(
            0.42
        );


        this.sprite.setDepth(
            20
        );
    }


    // =========================
    // FRAMES
    // =========================

    createFrames() {

        const texture =
            this.scene.textures.get(
                "playerSheet"
            );


        if (
            texture.has(
                "pistolIdle"
            )
        ) {

            return;
        }


        texture.add(
            "idle",
            0,
            993,
            20,
            150,
            225
        );


        texture.add(
            "pistolIdle",
            0,
            92,
            270,
            150,
            210
        );


        texture.add(
            "pistolShoot1",
            0,
            292,
            270,
            150,
            210
        );


        texture.add(
            "pistolShoot2",
            0,
            472,
            270,
            150,
            210
        );
    }


    // =========================
    // ANIMAÇÕES
    // =========================

    createAnimations() {

        if (
            this.scene.anims.exists(
                "player-pistol-shoot"
            )
        ) {

            return;
        }


        this.scene.anims.create({

            key:
                "player-pistol-shoot",

            frames: [

                {
                    key: "playerSheet",
                    frame: "pistolShoot1"
                },

                {
                    key: "playerSheet",
                    frame: "pistolShoot2"
                }
            ],

            frameRate: 12,

            repeat: 0
        });
    }


    // =========================
    // UPDATE
    // =========================

    update() {

        if (
            this.dead
        ) {

            return;
        }


        this.updateMovement();

        this.updateVisualPosition();

        this.lookAtPointer();


        if (
            !this.isShooting
        ) {

            this.setWeaponIdle();
        }
    }


    // =========================
    // MOVIMENTO
    // =========================

    updateMovement() {

        let velocityX = 0;
        let velocityY = 0;


        if (
            this.keys.left.isDown
        ) {

            velocityX--;
        }


        if (
            this.keys.right.isDown
        ) {

            velocityX++;
        }


        if (
            this.keys.up.isDown
        ) {

            velocityY--;
        }


        if (
            this.keys.down.isDown
        ) {

            velocityY++;
        }


        if (
            velocityX !== 0 ||
            velocityY !== 0
        ) {

            const vector =
                new Phaser.Math.Vector2(
                    velocityX,
                    velocityY
                )
                    .normalize()
                    .scale(
                        this.speed
                    );


            this.body.setVelocity(
                vector.x,
                vector.y
            );

        } else {

            this.body.setVelocity(
                0,
                0
            );
        }
    }


    // =========================
    // POSIÇÃO VISUAL
    // =========================

    updateVisualPosition() {

        this.sprite.setPosition(
            this.body.x,
            this.body.y
        );
    }


    // =========================
    // MIRA
    // =========================

    lookAtPointer() {

        const angle =
            this.getAimAngle();


        this.sprite.rotation =
            angle -
            Math.PI / 2;
    }


    // =========================
    // ALVO DO MOUSE
    // =========================

    getAimTarget() {

        const pointer =
            this.scene.input
                .activePointer;


        return (
            this.scene.cameras.main
                .getWorldPoint(
                    pointer.x,
                    pointer.y
                )
        );
    }


    // =========================
    // ÂNGULO
    // =========================

    getAimAngle() {

        const target =
            this.getAimTarget();


        return (
            Phaser.Math.Angle.Between(
                this.x,
                this.y,
                target.x,
                target.y
            )
        );
    }


    // =========================
    // POSIÇÃO DO CANO
    // =========================

    getGunPosition(
        angle =
            this.getAimAngle()
    ) {

        const gunDistance =
            45;


        return {

            x:
                this.x +
                Math.cos(angle) *
                gunDistance,

            y:
                this.y +
                Math.sin(angle) *
                gunDistance
        };
    }


    // =========================
    // ATIRA
    // =========================

    shoot(
        bulletsGroup
    ) {

        if (
            this.dead
        ) {

            return false;
        }


        const target =
            this.getAimTarget();


        return (
            this.weapon.shoot(
                this,

                target.x,
                target.y,

                bulletsGroup,

                "player"
            )
        );
    }


    // =========================
    // COMEÇA ANIMAÇÃO DE TIRO
    // =========================

    startShooting(
        animationKey
    ) {

        if (
            this.isShooting
        ) {

            return;
        }


        this.isShooting =
            true;


        if (
            !animationKey ||
            !this.scene.anims.exists(
                animationKey
            )
        ) {

            this.isShooting =
                false;

            return;
        }


        this.sprite.play(
            animationKey
        );


        this.sprite.once(

            Phaser.Animations.Events
                .ANIMATION_COMPLETE,

            () => {

                this.isShooting =
                    false;


                this.setWeaponIdle();
            }
        );
    }


    // =========================
    // IDLE DA ARMA
    // =========================

    setWeaponIdle() {

        this.sprite.anims.stop();


        if (
            this.currentWeapon ===
            "pistol"
        ) {

            this.sprite.setFrame(
                "pistolIdle"
            );

            return;
        }


        this.sprite.setFrame(
            "idle"
        );
    }


    // =========================
    // DANO
    // =========================

    takeDamage(
        damage
    ) {

        if (
            this.dead
        ) {

            return;
        }


        this.health -=
            damage;


        console.log(
            "Vida do player:",
            this.health
        );


        if (
            this.health <= 0
        ) {

            this.die();
        }
    }


    // =========================
    // MORTE
    // =========================

    die() {

        if (
            this.dead
        ) {

            return;
        }


        this.dead = true;


        this.body.setVelocity(
            0,
            0
        );


        console.log(
            "Player morreu"
        );


        // Marca que o próximo início
        // da sala é um respawn.

        this.scene.registry.set(
            "playerDied",
            true
        );


        this.scene.scene.restart();
    }


    // =========================
    // GETTERS
    // =========================

    get x() {

        return this.body.x;
    }


    get y() {

        return this.body.y;
    }
}