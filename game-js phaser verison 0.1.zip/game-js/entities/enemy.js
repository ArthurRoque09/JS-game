import { Weapon } from "../weapons/Weapon.js";
import { WEAPONS } from "../weapons/weaponsData.js";


export class Enemy extends Phaser.GameObjects.Rectangle {

    constructor(
        scene,
        x,
        y
    ) {

        super(
            scene,
            x,
            y,
            40,
            40,
            0xff0000
        );


        this.scene = scene;


        scene.add.existing(
            this
        );


        scene.physics.add.existing(
            this
        );


        // =========================
        // VIDA
        // =========================

        this.health = 100;

        this.dead = false;


        // =========================
        // IA
        // =========================

        this.state =
            "idle";

        this.speed =
            220;


        // =========================
        // ARMA
        // =========================

        this.weapon =
            new Weapon(
                scene,
                WEAPONS.PISTOLA
            );


        // Inimigos disparam
        // mais devagar que o player.

        this.weapon.shotCooldown =
            900;


        this.maxShootRange =
            550;


        this.angle =
            0;


        // =========================
        // MEMÓRIA
        // =========================

        this.lastSeenX =
            null;

        this.lastSeenY =
            null;


        // =========================
        // PATH
        // =========================

        this.path = [];

        this.pathIndex = 0;

        this.pathTimer = 0;

        this.pathUpdateInterval =
            500;


        // =========================
        // FÍSICA
        // =========================

        this.body.setSize(
            40,
            40
        );


        this.body.setCollideWorldBounds(
            true
        );


        this.setDepth(
            10
        );
    }


    // =========================
    // UPDATE
    // =========================

    update(
        player,
        walls,
        pathfinder,
        bullets,
        camera,
        delta
    ) {

        if (
            this.dead ||
            !this.active ||
            !player
        ) {

            return;
        }


        // =========================
        // DISTÂNCIA DO PLAYER
        // =========================

        const dx =
            player.x -
            this.x;


        const dy =
            player.y -
            this.y;


        const distance =
            Math.sqrt(
                dx * dx +
                dy * dy
            );


        // =========================
        // VISÃO
        // =========================

        const onScreen =
            this.isOnScreen(
                camera
            );


        const canSeePlayer =
            this.hasLineOfSight(
                player,
                walls
            );


        // =========================
        // ESCOLHE ESTADO
        // =========================

        this.chooseState(
            distance,
            canSeePlayer,
            player
        );


        // =========================
        // EXECUTA ESTADO
        // =========================

        switch (
            this.state
        ) {

            // =====================
            // PERSEGUIÇÃO
            // =====================

            case "chase":

                this.updatePathTo(
                    player.x,
                    player.y,
                    pathfinder,
                    delta
                );


                this.followPath();

                break;


            // =====================
            // PROCURA
            // =====================

            case "search":

                this.updatePathTo(
                    this.lastSeenX,
                    this.lastSeenY,
                    pathfinder,
                    delta
                );


                this.followPath();

                this.checkSearchArrival();

                break;


            // =====================
            // TIRO
            // =====================

            case "shoot":

                this.stop();


                this.angle =
                    Phaser.Math.Angle.Between(
                        this.x,
                        this.y,
                        player.x,
                        player.y
                    );


                // O inimigo continua
                // perseguindo fora da câmera,
                // mas só pode atirar
                // quando estiver visível.

                if (
                    onScreen
                ) {

                    this.weapon.shoot(
                        this,
                        player.x,
                        player.y,
                        bullets,
                        "enemy"
                    );
                }


                break;


            // =====================
            // IDLE
            // =====================

            default:

                this.stop();

                break;
        }
    }


    // =========================
    // ESCOLHE ESTADO
    // =========================

    chooseState(
        distance,
        canSeePlayer,
        player
    ) {

        // =========================
        // PLAYER VISÍVEL
        // =========================

        if (
            canSeePlayer
        ) {

            this.lastSeenX =
                player.x;

            this.lastSeenY =
                player.y;


            // Dentro do alcance:
            // para e atira.

            if (
                distance <=
                this.maxShootRange
            ) {

                this.state =
                    "shoot";


                this.clearPath();

                return;
            }


            // Fora do alcance:
            // persegue.

            this.state =
                "chase";

            return;
        }


        // =========================
        // PERDEU O PLAYER
        // =========================

        if (
            this.lastSeenX !== null &&
            this.lastSeenY !== null
        ) {

            this.state =
                "search";

            return;
        }


        // =========================
        // NUNCA VIU O PLAYER
        // =========================

        this.state =
            "idle";


        this.clearPath();
    }


    // =========================
    // ATUALIZA PATH
    // =========================

    updatePathTo(
        targetX,
        targetY,
        pathfinder,
        delta
    ) {

        if (
            targetX === null ||
            targetY === null ||
            !pathfinder
        ) {

            return;
        }


        this.pathTimer -=
            delta;


        if (
            this.pathTimer > 0 &&
            this.path.length > 0
        ) {

            return;
        }


        this.pathTimer =
            this.pathUpdateInterval;


        this.path =
            pathfinder.findPath(
                this.x,
                this.y,
                targetX,
                targetY
            );


        this.pathIndex =
            0;
    }


    // =========================
    // SEGUE PATH
    // =========================

    followPath() {

        if (
            !this.path ||
            this.path.length === 0
        ) {

            this.stop();

            return;
        }


        const target =
            this.path[
                this.pathIndex
            ];


        if (
            !target
        ) {

            this.stop();

            return;
        }


        let dx =
            target.x -
            this.x;


        let dy =
            target.y -
            this.y;


        const distance =
            Math.sqrt(
                dx * dx +
                dy * dy
            );


        // =========================
        // PRÓXIMO WAYPOINT
        // =========================

        if (
            distance <
            12
        ) {

            this.pathIndex++;


            if (
                this.pathIndex >=
                this.path.length
            ) {

                this.stop();
            }


            return;
        }


        // =========================
        // NORMALIZA MOVIMENTO
        // =========================

        dx /=
            distance;

        dy /=
            distance;


        this.body.setVelocity(
            dx *
            this.speed,

            dy *
            this.speed
        );
    }


    // =========================
    // CHEGOU NA ÚLTIMA POSIÇÃO
    // =========================

    checkSearchArrival() {

        if (
            this.lastSeenX === null ||
            this.lastSeenY === null
        ) {

            return;
        }


        const distance =
            Phaser.Math.Distance.Between(
                this.x,
                this.y,
                this.lastSeenX,
                this.lastSeenY
            );


        if (
            distance >
            30
        ) {

            return;
        }


        // =========================
        // ESQUECE O PLAYER
        // =========================

        this.lastSeenX =
            null;

        this.lastSeenY =
            null;


        this.state =
            "idle";


        this.clearPath();

        this.stop();
    }


    // =========================
    // ESTÁ NA TELA?
    // =========================

    isOnScreen(
        camera
    ) {

        if (
            !camera
        ) {

            return false;
        }


        const view =
            camera.worldView;


        return (
            this.x + 20 >
            view.left &&

            this.x - 20 <
            view.right &&

            this.y + 20 >
            view.top &&

            this.y - 20 <
            view.bottom
        );
    }


    // =========================
    // LINHA DE VISÃO
    // =========================

    hasLineOfSight(
        player,
        walls
    ) {

        if (
            !walls ||
            !walls.children
        ) {

            return false;
        }


        const line =
            new Phaser.Geom.Line(
                this.x,
                this.y,
                player.x,
                player.y
            );


        let blocked =
            false;


        walls.children.iterate(
            (wall) => {

                if (
                    blocked ||
                    !wall
                ) {

                    return;
                }


                if (
                    Phaser.Geom.Intersects
                        .LineToRectangle(
                            line,
                            wall.getBounds()
                        )
                ) {

                    blocked =
                        true;
                }
            }
        );


        return !blocked;
    }


    // =========================
    // POSIÇÃO DO CANO
    // =========================

    getGunPosition(
        angle =
            this.angle
    ) {

        const gunDistance =
            40;


        return {

            x:
                this.x +
                Math.cos(
                    angle
                ) *
                gunDistance,

            y:
                this.y +
                Math.sin(
                    angle
                ) *
                gunDistance
        };
    }


    // =========================
    // LIMPA PATH
    // =========================

    clearPath() {

        this.path = [];

        this.pathIndex = 0;

        this.pathTimer = 0;
    }


    // =========================
    // PARA MOVIMENTO
    // =========================

    stop() {

        this.body.setVelocity(
            0,
            0
        );
    }


    // =========================
    // DANO
    // =========================

    takeDamage(
        damage
    ) {

        if (
            this.dead
        ) {

            return;
        }


        this.health -=
            damage;


        if (
            this.health <= 0
        ) {

            this.die();
        }
    }


    // =========================
    // MORTE
    // =========================

    die() {

        if (
            this.dead
        ) {

            return;
        }


        this.dead =
            true;


        this.stop();


        this.destroy();
    }
}