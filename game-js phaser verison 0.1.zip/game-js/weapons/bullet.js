export class Bullet extends Phaser.GameObjects.Arc {

    constructor(
        scene,
        x,
        y,
        angle,
        speed,
        damage,
        owner
    ) {

        super(
            scene,
            x,
            y,
            5,
            0,
            360,
            false,
            0xffff00
        );


        this.scene =
            scene;


        this.damage =
            damage;


        this.owner =
            owner;


        // =========================
        // ADICIONA À CENA
        // =========================

        scene.add.existing(
            this
        );


        // =========================
        // FÍSICA
        // =========================

        scene.physics.add.existing(
            this
        );


        // =========================
        // HITBOX DA BALA
        // =========================

        this.body.setCircle(
            5
        );


        this.body.setAllowGravity(
            false
        );


        // =========================
        // ORDEM VISUAL
        // =========================

        this.setDepth(
            30
        );


        // =========================
        // VELOCIDADE
        // =========================

        this.body.setVelocity(
            Math.cos(
                angle
            ) *
                speed,

            Math.sin(
                angle
            ) *
                speed
        );
    }
}