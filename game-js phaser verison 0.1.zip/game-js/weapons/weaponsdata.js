export const WEAPONS = {

    PISTOLA: {

        name: "PISTOLA",

        type: "single",

        automatic: false,

        damage: 100,

        shotCooldown: 400,

        bulletSpeed: 900,

        bulletLifeTime: 2000,

        magazineSize: 30,

        shootAnimation:
            "player-pistol-shoot"
    }
};