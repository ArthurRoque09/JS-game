import { Bullet } from "./Bullet.js";


export class Weapon {

    constructor(
        scene,
        data
    ) {

        this.scene = scene;

        this.name = data.name;

        this.type = data.type;

        this.automatic = data.automatic;

        this.damage = data.damage;

        this.shotCooldown =
            data.shotCooldown;

        this.bulletSpeed =
            data.bulletSpeed;

        this.bulletLifeTime =
            data.bulletLifeTime;

        this.magazineSize =
            data.magazineSize;

        this.ammo =
            this.magazineSize;

        this.shootAnimation =
            data.shootAnimation;

        this.lastShotTime = 0;
    }


    // =========================
    // PODE ATIRAR?
    // =========================

    canShoot(
        owner
    ) {

        // =========================
        // MUNIÇÃO
        // =========================

        // Por enquanto apenas o player
        // possui munição limitada.
        //
        // Inimigos têm munição infinita.

        if (
            owner === "player" &&
            this.ammo <= 0
        ) {

            return false;
        }


        // =========================
        // COOLDOWN
        // =========================

        const now =
            this.scene.time.now;


        return (
            now -
            this.lastShotTime >=
            this.shotCooldown
        );
    }


    // =========================
    // DISPARO UNIVERSAL
    // =========================

    shoot(
        shooter,
        targetX,
        targetY,
        bulletsGroup,
        owner
    ) {

        // =========================
        // PODE ATIRAR?
        // =========================

        if (
            !this.canShoot(
                owner
            )
        ) {

            return false;
        }


        // =========================
        // ANIMAÇÃO EM ANDAMENTO
        // =========================

        if (
            shooter.isShooting === true
        ) {

            return false;
        }


        // =========================
        // ÂNGULO
        // =========================

        const angle =
            Phaser.Math.Angle.Between(
                shooter.x,
                shooter.y,
                targetX,
                targetY
            );


        // =========================
        // POSIÇÃO DO CANO
        // =========================

        const gunPosition =
            shooter.getGunPosition(
                angle
            );


        // =========================
        // CRIA BALA
        // =========================

        const bullet =
            new Bullet(
                this.scene,

                gunPosition.x,
                gunPosition.y,

                angle,

                this.bulletSpeed,

                this.damage,

                owner
            );


        bulletsGroup.add(
            bullet
        );


        // O Physics Group pode alterar
        // o body ao adicionar a bala.
        // Por isso aplicamos velocidade
        // novamente DEPOIS do add().

        bullet.body.setVelocity(
            Math.cos(angle) *
            this.bulletSpeed,

            Math.sin(angle) *
            this.bulletSpeed
        );


        // =========================
        // GASTA MUNIÇÃO
        // =========================

        // Apenas o player gasta munição.
        //
        // Inimigos possuem munição
        // infinita por enquanto.

        if (
            owner === "player"
        ) {

            this.ammo--;
        }


        // =========================
        // TEMPO DE VIDA
        // =========================

        this.scene.time.delayedCall(

            this.bulletLifeTime,

            () => {

                if (
                    bullet.active
                ) {

                    bullet.destroy();
                }
            }
        );


        // =========================
        // ANIMAÇÃO DO SHOOTER
        // =========================

        if (
            typeof shooter.startShooting ===
            "function"
        ) {

            shooter.startShooting(
                this.shootAnimation
            );
        }


        // =========================
        // COOLDOWN
        // =========================

        this.lastShotTime =
            this.scene.time.now;


        return true;
    }
}