export const MAP_WALLS = [

    // =========================
    // SALA INICIAL
    // =========================

    {
        x: 175,
        y: 5,
        width: 10,
        height: 115
    },

    {
        x: 310,
        y: 5,
        width: 10,
        height: 115
    },

    {
        x: 175,
        y: 5,
        width: 145,
        height: 10
    },

    {
        x: 175,
        y: 110,
        width: 40,
        height: 10
    },

    {
        x: 270,
        y: 110,
        width: 50,
        height: 10
    },


    // =========================
    // PAREDES EXTERNAS
    // =========================

    {
        x: 0,
        y: 120,
        width: 215,
        height: 12
    },

    {
        x: 270,
        y: 120,
        width: 950,
        height: 12
    },

    {
        x: 0,
        y: 120,
        width: 12,
        height: 700
    },

    {
        x: 1220,
        y: 120,
        width: 12,
        height: 700
    },

    {
        x: 5,
        y: 810,
        width: 1220,
        height: 12
    },


    // =========================
    // SALA SUPERIOR ESQUERDA
    // =========================

    {
        x: 160,
        y: 120,
        width: 12,
        height: 170
    },

    {
        x: 160,
        y: 280,
        width: 220,
        height: 12
    },


    // =========================
    // CORREDOR CENTRAL
    // =========================

    {
        x: 375,
        y: 280,
        width: 12,
        height: 50
    },

    {
        x: 375,
        y: 385,
        width: 12,
        height: 320
    },

    {
        x: 530,
        y: 280,
        width: 12,
        height: 50
    },

    {
        x: 530,
        y: 385,
        width: 12,
        height: 65
    },


    // =========================
    // SALA SUPERIOR DIREITA
    // =========================

    {
        x: 690,
        y: 120,
        width: 12,
        height: 55
    },

    {
        x: 690,
        y: 227,
        width: 12,
        height: 65
    },

    {
        x: 530,
        y: 280,
        width: 265,
        height: 12
    },

    {
        x: 795,
        y: 280,
        width: 12,
        height: 50
    },

    {
        x: 795,
        y: 385,
        width: 12,
        height: 65
    },

    {
        x: 480,
        y: 440,
        width: 327,
        height: 12
    },


    // =========================
    // SALA CREME ESQUERDA
    // =========================

    {
        x: 80,
        y: 435,
        width: 12,
        height: 65
    },


    // =========================
    // SALA VERDE CENTRAL
    // =========================

    {
        x: 375,
        y: 440,
        width: 50,
        height: 12
    },

    {
        x: 635,
        y: 440,
        width: 12,
        height: 220
    },


    // =========================
    // SALA BRANCA SUPERIOR
    // =========================

    {
        x: 0,
        y: 490,
        width: 385,
        height: 12
    },

    {
        x: 160,
        y: 650,
        width: 220,
        height: 12
    },


    // =========================
    // SALA BRANCA INFERIOR
    // =========================

    {
        x: 375,
        y: 760,
        width: 12,
        height: 50
    },


    // =========================
    // SALA DE TIJOLOS
    // =========================

    {
        x: 375,
        y: 595,
        width: 150,
        height: 12
    },

    {
        x: 590,
        y: 595,
        width: 55,
        height: 12
    },

    {
        x: 640,
        y: 650,
        width: 165,
        height: 12
    },

    {
        x: 795,
        y: 650,
        width: 12,
        height: 45
    },

    {
        x: 795,
        y: 760,
        width: 12,
        height: 55
    },


    // =========================
    // BANCADAS
    // =========================

    {
        x: 955,
        y: 245,
        width: 135,
        height: 38
    },

    {
        x: 1090,
        y: 245,
        width: 130,
        height: 38
    },

    {
        x: 955,
        y: 335,
        width: 135,
        height: 38
    },

    {
        x: 1090,
        y: 335,
        width: 130,
        height: 38
    },

    {
        x: 935,
        y: 625,
        width: 40,
        height: 135
    },

    {
        x: 1095,
        y: 625,
        width: 40,
        height: 135
    }
];