import { Enemy } from "../entities/Enemy.js";
import { Player } from "../entities/Player.js";
import { MAP_WALLS } from "../world/MapWalls.js";
import { NavigationGrid } from "../systems/NavigationGrid.js";
import { Pathfinder } from "../systems/Pathfinder.js";

export class GameScene extends Phaser.Scene {

    constructor() {

        super(
            "GameScene"
        );
    }


    // =========================
    // PRELOAD
    // =========================

    preload() {

        this.load.audio(
            "deathSound",
            "./assets/Death.mp3"
        );

        this.load.image(
            "map",
            "./assets/Mapa.png"
        );


        this.load.image(
            "playerSheet",
            "./assets/spritesheet-player.png"
        );
    }


    // =========================
    // CREATE
    // =========================

    create() {

        // =========================
        // SOM DE RESPAWN
        // =========================

        if (
            this.registry.get(
                "playerDied"
            ) === true
        ) {

            this.sound.play(
                "deathSound",
                {
                    seek: 1.2
                }
            );

            this.registry.set(
                "playerDied",
                false
            );
        }

        // =========================
        // CONFIGURAÇÕES
        // =========================

        this.MAP_SCALE =
            2.5;


        this.DEBUG_COLLIDERS =
            false;


        // Quantidade de inimigos
        // gerados na sala.

        this.ENEMY_COUNT =
            3;


        // Distância mínima entre
        // spawn do player e inimigo.

        this.MIN_ENEMY_SPAWN_DISTANCE =
            500;


        // =========================
        // MAPA
        // =========================

        this.createMap();


        // =========================
        // PAREDES
        // =========================

        this.createWalls();


        // =========================
        // NAVEGAÇÃO
        // =========================

        this.createNavigation();


        // =========================
        // PLAYER
        // =========================

        this.player =
            new Player(
                this,

                230 *
                this.MAP_SCALE,

                55 *
                this.MAP_SCALE,

                this.walls
            );


        // =========================
        // BALAS
        // =========================

        this.createBullets();


        // =========================
        // INIMIGOS
        // =========================

        this.createEnemies();


        // =========================
        // COLISÕES
        // =========================

        this.createCollisions();


        // =========================
        // CÂMERA
        // =========================

        this.createCamera();


        // =========================
        // INPUT
        // =========================

        this.createInput();


        // =========================
        // HUD
        // =========================

        this.createHUD();
    }


    // =========================
    // CRIA MAPA
    // =========================

    createMap() {

        this.map =
            this.add.image(
                0,
                0,
                "map"
            )
                .setOrigin(
                    0
                );


        this.map.setScale(
            this.MAP_SCALE
        );


        this.mapWidth =
            this.map.displayWidth;


        this.mapHeight =
            this.map.displayHeight;


        this.physics.world.setBounds(
            0,
            0,
            this.mapWidth,
            this.mapHeight
        );
    }


    // =========================
    // CRIA PAREDES
    // =========================

    createWalls() {

        this.walls =
            this.physics.add.staticGroup();


        let wallId =
            1;


        for (
            const wallData
            of MAP_WALLS
        ) {

            const x =
                wallData.x *
                this.MAP_SCALE;


            const y =
                wallData.y *
                this.MAP_SCALE;


            const width =
                wallData.width *
                this.MAP_SCALE;


            const height =
                wallData.height *
                this.MAP_SCALE;


            this.createWall(
                wallId,

                x +
                width / 2,

                y +
                height / 2,

                width,
                height
            );


            wallId++;
        }
    }


    // =========================
    // SISTEMA DE NAVEGAÇÃO
    // =========================

    createNavigation() {

        this.navigationGrid =
            new NavigationGrid(
                this.mapWidth,
                this.mapHeight,
                this.walls,

                {
                    cellSize: 40,

                    padding: 32
                }
            );


        this.pathfinder =
            new Pathfinder(
                this.navigationGrid
            );
    }


    // =========================
    // CRIA UMA PAREDE
    // =========================

    createWall(
        id,
        x,
        y,
        width,
        height
    ) {

        const alpha =
            this.DEBUG_COLLIDERS
                ? 0.35
                : 0;


        const wall =
            this.add.rectangle(
                x,
                y,
                width,
                height,
                0xff0000,
                alpha
            );


        this.physics.add.existing(
            wall,
            true
        );


        this.walls.add(
            wall
        );


        // =========================
        // DEBUG VISUAL
        // =========================

        if (
            this.DEBUG_COLLIDERS
        ) {

            const label =
                this.add.text(
                    x,
                    y,

                    `W${id}`,

                    {
                        fontSize:
                            "18px",

                        color:
                            "#ffff00",

                        backgroundColor:
                            "#000000"
                    }
                );


            label.setOrigin(
                0.5
            );
        }


        return wall;
    }


    // =========================
    // BALAS
    // =========================

    createBullets() {

        this.bullets =
            this.physics.add.group();
    }


    // =========================
    // INIMIGOS
    // =========================

    // =========================
    // INIMIGOS
    // =========================

    createEnemies() {

        this.enemies =
            this.physics.add.group();


        // Todas as posições da grid
        // realmente alcançáveis pelo player.

        this.enemySpawnCells =
            this.navigationGrid
                .getReachableCellsFrom(
                    this.player.x,
                    this.player.y
                );


        for (
            let i = 0;
            i < this.ENEMY_COUNT;
            i++
        ) {

            const spawn =
                this.findRandomEnemySpawn();


            if (
                !spawn
            ) {

                console.warn(
                    "Não foi possível encontrar spawn válido para inimigo."
                );

                continue;
            }


            this.spawnEnemy(
                spawn.x,
                spawn.y
            );
        }
    }


    // =========================
    // PROCURA SPAWN ALEATÓRIO
    // =========================

    findRandomEnemySpawn() {

        if (
            !this.enemySpawnCells ||
            this.enemySpawnCells.length === 0
        ) {

            return null;
        }


        const maxAttempts =
            200;


        for (
            let attempt = 0;
            attempt < maxAttempts;
            attempt++
        ) {

            const cell =
                Phaser.Utils.Array.GetRandom(
                    this.enemySpawnCells
                );


            const position =
                this.navigationGrid
                    .gridToWorld(
                        cell.col,
                        cell.row
                    );


            // =========================
            // DISTÂNCIA DO PLAYER
            // =========================

            const distanceFromPlayer =
                Phaser.Math.Distance.Between(
                    position.x,
                    position.y,
                    this.player.x,
                    this.player.y
                );


            if (
                distanceFromPlayer <
                this.MIN_ENEMY_SPAWN_DISTANCE
            ) {

                continue;
            }


            // =========================
            // DISTÂNCIA DE OUTRO INIMIGO
            // =========================

            let tooClose =
                false;


            this.enemies.children.iterate(
                (enemy) => {

                    if (
                        tooClose ||
                        !enemy ||
                        !enemy.active
                    ) {

                        return;
                    }


                    const distance =
                        Phaser.Math.Distance.Between(
                            position.x,
                            position.y,
                            enemy.x,
                            enemy.y
                        );


                    if (
                        distance <
                        80
                    ) {

                        tooClose =
                            true;
                    }
                }
            );


            if (
                tooClose
            ) {

                continue;
            }


            return {

                x:
                    position.x,

                y:
                    position.y
            };
        }


        return null;
    }

    // =========================
    // SPAWN DE INIMIGO
    // =========================

    spawnEnemy(
        x,
        y
    ) {

        const enemy =
            new Enemy(
                this,
                x,
                y
            );


        this.enemies.add(
            enemy
        );


        return enemy;
    }


    // =========================
    // COLISÕES
    // =========================

    createCollisions() {

        // =========================
        // BALAS x PAREDES
        // =========================

        this.physics.add.collider(
            this.bullets,
            this.walls,

            (bullet) => {

                if (
                    bullet.active
                ) {

                    bullet.destroy();
                }
            }
        );


        // =========================
        // INIMIGOS x PAREDES
        // =========================

        this.physics.add.collider(
            this.enemies,
            this.walls
        );


        // =========================
        // INIMIGOS x INIMIGOS
        // =========================

        this.physics.add.collider(
            this.enemies,
            this.enemies
        );


        // =========================
        // BALAS x INIMIGOS
        // =========================

        this.physics.add.overlap(
            this.bullets,
            this.enemies,

            (
                bullet,
                enemy
            ) => {

                this.hitEnemy(
                    bullet,
                    enemy
                );
            }
        );


        // =========================
        // BALAS x PLAYER
        // =========================

        this.physics.add.overlap(
            this.bullets,
            this.player.body,

            (
                object1,
                object2
            ) => {

                const bullet =
                    object1.owner !==
                        undefined

                        ? object1
                        : object2;


                this.hitPlayer(
                    bullet
                );
            }
        );
    }


    // =========================
    // DANO NO PLAYER
    // =========================

    hitPlayer(
        bullet
    ) {

        if (
            !bullet ||
            !bullet.active
        ) {

            return;
        }


        if (
            bullet.owner !==
            "enemy"
        ) {

            return;
        }


        const damage =
            bullet.damage;


        bullet.destroy();


        this.player.takeDamage(
            damage
        );
    }


    // =========================
    // DANO NO INIMIGO
    // =========================

    hitEnemy(
        bullet,
        enemy
    ) {

        if (
            !bullet.active ||
            !enemy.active
        ) {

            return;
        }


        // Bala de inimigo não
        // acerta outros inimigos.

        if (
            bullet.owner !==
            "player"
        ) {

            return;
        }


        const damage =
            bullet.damage;


        bullet.destroy();


        enemy.takeDamage(
            damage
        );
    }


    // =========================
    // CÂMERA
    // =========================

    createCamera() {

        this.cameras.main.setBounds(
            0,
            0,
            this.mapWidth,
            this.mapHeight
        );


        this.cameras.main.startFollow(
            this.player.body,
            true,
            0.1,
            0.1
        );
    }


    // =========================
    // INPUT
    // =========================

    createInput() {

        this.input.on(
            "pointerdown",

            (pointer) => {

                if (
                    pointer.leftButtonDown()
                ) {

                    this.player.shoot(
                        this.bullets
                    );
                }
            }
        );
    }


    // =========================
    // HUD
    // =========================

    createHUD() {

        const hudWidth =
            220;

        const hudHeight =
            90;

        const marginRight =
            25;

        const marginBottom =
            25;


        const hudX =
            this.cameras.main.width -
            hudWidth -
            marginRight;


        const hudY =
            this.cameras.main.height -
            hudHeight -
            marginBottom;


        // =========================
        // FUNDO
        // =========================

        this.hudBackground =
            this.add.rectangle(
                hudX,
                hudY,
                hudWidth,
                hudHeight,
                0x303030,
                0.75
            );


        this.hudBackground.setOrigin(
            0,
            0
        );


        this.hudBackground.setStrokeStyle(
            3,
            0x777777,
            1
        );


        // =========================
        // ARMA
        // =========================

        this.weaponText =
            this.add.text(
                hudX + 15,
                hudY + 12,
                "",
                {
                    fontFamily:
                        "Arial",

                    fontSize:
                        "20px",

                    fontStyle:
                        "bold",

                    color:
                        "#ffffff"
                }
            );


        // =========================
        // MUNIÇÃO
        // =========================

        this.ammoText =
            this.add.text(
                hudX + 15,
                hudY + 42,
                "",
                {
                    fontFamily:
                        "Arial",

                    fontSize:
                        "30px",

                    fontStyle:
                        "bold",

                    color:
                        "#ffffff"
                }
            );


        // =========================
        // FIXA NA TELA
        // =========================

        this.hudBackground
            .setScrollFactor(0)
            .setDepth(1000);


        this.weaponText
            .setScrollFactor(0)
            .setDepth(1001);


        this.ammoText
            .setScrollFactor(0)
            .setDepth(1001);


        this.updateHUD();
    }


    // =========================
    // ATUALIZA HUD
    // =========================

    updateHUD() {

        if (
            !this.player ||
            !this.player.weapon
        ) {

            return;
        }


        const weapon =
            this.player.weapon;


        this.weaponText.setText(
            weapon.name
        );


        this.ammoText.setText(
            `${weapon.ammo} / ${weapon.magazineSize}`
        );
    }


    // =========================
    // UPDATE DOS INIMIGOS
    // =========================

    updateEnemies(
        delta
    ) {

        this.enemies.children.iterate(
            (enemy) => {

                if (
                    !enemy ||
                    !enemy.active
                ) {

                    return;
                }


                enemy.update(
                    this.player.body,
                    this.walls,
                    this.pathfinder,
                    this.bullets,
                    this.cameras.main,
                    delta
                );
            }
        );
    }


    // =========================
    // UPDATE
    // =========================

    update(
        time,
        delta
    ) {

        this.player.update();


        this.updateEnemies(
            delta
        );


        this.updateHUD();
    }
}