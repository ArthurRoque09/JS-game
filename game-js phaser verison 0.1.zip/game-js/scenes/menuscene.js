export class MenuScene extends Phaser.Scene {

    constructor() {

        super(
            "MenuScene"
        );
    }


    create() {

        const centerX =
            this.scale.width / 2;

        const centerY =
            this.scale.height / 2;


        // =========================
        // TÍTULO
        // =========================

        this.add.text(
            centerX,
            centerY - 120,
            "HOTLINE PROJECT",
            {
                fontSize: "52px",
                color: "#ff33cc",
                fontStyle: "bold"
            }
        )
        .setOrigin(0.5);


        // =========================
        // CONTROLES
        // =========================

        this.add.text(
            centerX,
            centerY,
            "WASD - Movimento\nMouse - Mirar\nClique - Atirar\nE - Interagir",
            {
                fontSize: "22px",
                color: "#ffffff",
                align: "center"
            }
        )
        .setOrigin(0.5);


        // =========================
        // INICIAR
        // =========================

        const startText =
            this.add.text(
                centerX,
                centerY + 170,
                "CLIQUE PARA JOGAR",
                {
                    fontSize: "26px",
                    color: "#00ffff"
                }
            )
            .setOrigin(0.5)
            .setInteractive();


        startText.on(
            "pointerdown",
            () => {

                this.scene.start(
                    "GameScene"
                );
            }
        );
    }
}