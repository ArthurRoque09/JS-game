import { MenuScene } from "./scenes/MenuScene.js";
import { GameScene } from "./scenes/GameScene.js";


const config = {

    type: Phaser.AUTO,

    width: 1200,
    height: 800,

    backgroundColor: "#000000",


    // =========================
    // FÍSICA
    // =========================

    physics: {

        default: "arcade",

        arcade: {

            gravity: {
                y: 0
            },

            debug: false
        }
    },


    // =========================
    // CENAS
    // =========================

    scene: [
        MenuScene,
        GameScene
    ]
};


new Phaser.Game(config);