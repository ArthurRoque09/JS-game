export class GroundWeapon extends Phaser.GameObjects.Sprite {

    constructor(
        scene,
        x,
        y,
        weaponKey,
        weaponData,
        ammo = null
    ) {

        // =========================
        // CRIA FRAMES DAS ARMAS
        // =========================

        GroundWeapon.createFrames(
            scene
        );


        const frameKey =
            GroundWeapon.getFrameKey(
                weaponKey
            );


        super(
            scene,
            x,
            y,
            "weaponSheet",
            frameKey
        );


        this.scene =
            scene;


        // =========================
        // DADOS DA ARMA
        // =========================

        this.weaponKey =
            weaponKey;


        this.weaponData =
            weaponData;


        this.ammo =
            ammo !== null
                ? ammo
                : weaponData.magazineSize;


        // =========================
        // ADICIONA À CENA
        // =========================

        scene.add.existing(
            this
        );


        // =========================
        // FÍSICA
        // =========================

        scene.physics.add.existing(
            this
        );


        this.body.setAllowGravity(
            false
        );


        this.body.setImmovable(
            true
        );


        this.body.moves =
            false;


        // =========================
        // HITBOX
        // =========================

        this.configureHitbox();


        // =========================
        // VISUAL
        // =========================

        this.setScale(
            0.55
        );


        this.setDepth(
            15
        );


        // Pequena rotação para parecer
        // realmente largada no chão.

        this.setRotation(
            Phaser.Math.FloatBetween(
                -0.25,
                0.25
            )
        );
    }


    // =========================
    // CRIA FRAMES
    // =========================

    static createFrames(
        scene
    ) {

        const texture =
            scene.textures.get(
                "weaponSheet"
            );


        if (
            texture.has(
                "groundPistol"
            )
        ) {

            return;
        }


        // =========================
        // AK / FUTURA ARMA
        // =========================

        texture.add(
            "groundRifle",
            0,
            24,
            49,
            186,
            61
        );


        // =========================
        // DOZE
        // =========================

        texture.add(
            "groundShotgun",
            0,
            242,
            57,
            173,
            37
        );


        // =========================
        // PISTOLA
        // =========================

        texture.add(
            "groundPistol",
            0,
            486,
            59,
            79,
            50
        );


        // =========================
        // CARTUCHO PEQUENO
        // =========================

        texture.add(
            "smallShell",
            0,
            263,
            266,
            73,
            67
        );


        // =========================
        // CARTUCHO DA DOZE
        // =========================

        texture.add(
            "shotgunShell",
            0,
            415,
            240,
            86,
            109
        );
    }


    // =========================
    // FRAME DA ARMA
    // =========================

    static getFrameKey(
        weaponKey
    ) {

        switch (
        weaponKey
        ) {

            case "PISTOLA":

                return "groundPistol";


            case "DOZE":

                return "groundShotgun";


            // Já deixamos preparado
            // para uma futura arma longa.

            case "RIFLE":
            case "AK":

                return "groundRifle";


            default:

                return "groundPistol";
        }
    }


    // =========================
    // HITBOX
    // =========================

    configureHitbox() {

        switch (
        this.weaponKey
        ) {

            case "PISTOLA":

                this.body.setSize(
                    55,
                    35
                );

                break;


            case "DOZE":

                this.body.setSize(
                    120,
                    30
                );

                break;


            case "RIFLE":
            case "AK":

                this.body.setSize(
                    130,
                    40
                );

                break;


            default:

                this.body.setSize(
                    50,
                    30
                );

                break;
        }
    }


    // =========================
    // DADOS
    // =========================

    getWeaponData() {

        return this.weaponData;
    }


    getWeaponKey() {

        return this.weaponKey;
    }


    getAmmo() {

        return this.ammo;
    }
}