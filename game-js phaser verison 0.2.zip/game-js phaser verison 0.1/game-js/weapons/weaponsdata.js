export const WEAPONS = {

    PISTOLA: {

        name: "PISTOLA",

        type: "single",

        automatic: false,

        damage: 100,

        shotCooldown: 400,

        bulletSpeed: 1650,

        bulletLifeTime: 2000,

        magazineSize: 30,

        pellets: 1,

        spread: 0,

        shellType:
            "small",

        shootAnimation:
            "player-pistol-shoot"
    },


    DOZE: {

        name: "DOZE",

        type: "shotgun",

        automatic: false,

        damage: 100,

        shotCooldown: 850,

        bulletSpeed: 1650,

        bulletLifeTime: 1200,

        magazineSize: 8,

        pellets: 6,

        spread: 0.10,

        shellType:
            "shotgun",

        shootAnimation:
            "player-shotgun-shoot"
    }
};