import { Player } from "../entities/player.js";
import { Enemy } from "../entities/enemy.js";
import { Bullet } from "../weapons/bullet.js";
import { Map } from "./mapa.js";
import { Camera } from "../core/camera.js"

const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

const keys = {};
const bullets = [];
const player = new Player(100, 180);

const camera = new Camera (canvas.width, canvas.height);

const map = new Map("../assets/Mapa.png")

let mouseX = 0;
let mouseY = 0;
let mousePressed = false;

canvas.addEventListener("mousemove", (e) => {

    const rect = canvas.getBoundingClientRect();

    mouseX = e.clientX - rect.left + camera.x;
    mouseY = e.clientY - rect.top + camera.y;

});

const enemies = [];

enemies.push(new Enemy(500, 500));

function updateEnemies(){

    for(let i = 0; i < enemies.length; i++){

        enemies[i].update();

        if(enemies[i].health <= 0){

            enemies.splice(i,1);

            i--;

        }

    }

}
function drawEnemies() {

    for (const enemy of enemies) {
        enemy.draw(ctx);
    }

}



let isReloading = false;
let reloadStartTime = 0;
const reloadDuration = 2000;

// controle de tiro
let lastShotTime = 0;

const weapons = {
    PISTOLA: {
        automatic: false,
        shotCooldown: 140,
        bulletSpeed: 8,
        damage: 25
    }
};

let ammo = 30;
let maxAmmo = 30;

let currentWeapon = "PISTOLA";




window.addEventListener("keydown", (e) => {
    keys[e.key] = true;

    if (e.key.toLowerCase() === "r" && !isReloading && ammo < maxAmmo) {
        isReloading = true;
        reloadStartTime = Date.now();
    }
});

window.addEventListener("keyup", (e) => {
    keys[e.key] = false;
});

canvas.addEventListener("mousedown", () => {

    mousePressed = true;

    if (
        !isReloading &&
        !weapons[currentWeapon].automatic
    ) {
        shoot();
    }

});

canvas.addEventListener("mouseup", () => {
    mousePressed = false;
});

canvas.addEventListener("mouseleave", () => {
    mousePressed = false;
});

function shoot() {

    const now = Date.now();
    const weapon = weapons[currentWeapon];

    if (now - lastShotTime < weapon.shotCooldown) {
        return;
    }

    if (ammo <= 0) {
        return;
    }

    const gunPosition = player.getGunPosition();

    const startX = gunPosition.x;
    const startY = gunPosition.y;

    let dx = mouseX - startX;
    let dy = mouseY - startY;

    const distance = Math.sqrt(dx * dx + dy * dy);

    if (distance === 0) {
        return;
    }

    dx /= distance;
    dy /= distance;

    bullets.push(
        new Bullet(
            startX,
            startY,
            dx * weapon.bulletSpeed,
            dy * weapon.bulletSpeed
        )
    );

    ammo--;

    lastShotTime = now;

    player.startShooting();
}

function updateBullets(){

    for(let i = 0; i < bullets.length; i++){

        bullets[i].update();

        if(
            bullets[i].x < 0 ||
            bullets[i].x > 6020 ||
            bullets[i].y < 0 ||
            bullets[i].y > 3360
        ){

            bullets.splice(i,1);
            i--;

        }

    }

}

function drawBullets(){

    for(const bullet of bullets){

        bullet.draw(ctx);

    }

}

function checkBulletCollision() {

    for (let i = 0; i < bullets.length; i++) {

        const bullet = bullets[i];

        for (let j = 0; j < enemies.length; j++) {

            const enemy = enemies[j];

            if (

                bullet.x > enemy.x &&
                bullet.x < enemy.x + enemy.width &&
                bullet.y > enemy.y &&
                bullet.y < enemy.y + enemy.height

            ) {

                enemy.takeDamage(bullet.damage);

                bullets.splice(i, 1);

                i--;

                break;

            }

        }

    }

}

function drawHUD() {

    const boxWidth = 180;
    const boxHeight = 90;

    const boxX = canvas.width - boxWidth - 25;
    const boxY = canvas.height - boxHeight - 25;

    // Fundo da caixa
    ctx.fillStyle = "rgba(0, 0, 0, 0.75)";
    ctx.fillRect(boxX, boxY, boxWidth, boxHeight);

    // Borda
    ctx.strokeStyle = "white";
    ctx.lineWidth = 2;
    ctx.strokeRect(boxX, boxY, boxWidth, boxHeight);

    // Munição
    ctx.fillStyle = ammo <= 5 ? "red" : "white";
    ctx.font = "bold 42px Arial";
    ctx.textAlign = "center";

    ctx.fillText(
        ammo,
        boxX + boxWidth / 2,
        boxY + 48
    );

    // Nome da arma
    ctx.fillStyle = "white";
    ctx.font = "bold 16px Arial";

    ctx.fillText(
        currentWeapon,
        boxX + boxWidth / 2,
        boxY + 73
    );

    // Volta o alinhamento normal
    ctx.textAlign = "left";

}

function update(deltaTime) {

    player.update(keys, deltaTime);

    player.lookAt(mouseX, mouseY);

    if (mousePressed && !isReloading) {
        shoot();
    }

    camera.follow(player);

    updateBullets();

    updateEnemies();

    checkBulletCollision();

}

function render(){

    ctx.clearRect(0,0,canvas.width,canvas.height);

    ctx.save();

    ctx.translate(-camera.x,-camera.y);

    map.draw(ctx);

    player.draw(ctx);

    drawBullets();

    drawEnemies();

    ctx.restore();

    drawHUD();

}

let lastTime = 0;

function gameLoop(timestamp) {

    const deltaTime = timestamp - lastTime;

    lastTime = timestamp;

    update(deltaTime);

    render();

    requestAnimationFrame(gameLoop);

}

requestAnimationFrame(gameLoop);
